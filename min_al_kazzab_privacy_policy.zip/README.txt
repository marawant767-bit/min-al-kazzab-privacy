مين الكذاب؟ — Privacy Policy

Files:
- index.html — the privacy policy page.

How to publish:
1. Create a public GitHub repository.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Set the publishing source to the main branch and / (root).
5. Wait for GitHub Pages to publish.
6. Use the resulting HTTPS page URL as the Privacy Policy URL in APKPure.

Example URL format:
https://YOUR-GITHUB-USERNAME.github.io/REPOSITORY-NAME/
